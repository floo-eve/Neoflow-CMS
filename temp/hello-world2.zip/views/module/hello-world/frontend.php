<span>Section ID: <?= $view->get('section_id') ?></span>
<p><?= $message->message ?></p>
