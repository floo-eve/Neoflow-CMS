<?php

$this->addTranslation(array(
    'Message' => 'Message',
    'Change your "Hello World" message here.' => 'Change your "Hello World" message here.',
));
